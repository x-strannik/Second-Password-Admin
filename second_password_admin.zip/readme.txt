=== Second Password Admin ===
Plugin Name: Second Password Admin
Plugin URI: https://kodabra.unchikov.ru/second-password-for-admin/
Description: The second password for the admin
Author: Elena Unchikova
Version: 1
Author URI: https://kodabra.unchikov.ru/

Плагин двухфакторной аутентификации для Администратора WordPress.

== Description ==

Плагин двухфакторной аутентификации для Администратора WordPress.
Не забудьте вместо «ваша_эл_почта» вписать ваш E-mail, а вместо «ваш_второй_пароль» — ваш второй пароль администратора.
При аутентификации администратора он будет перенаправлен на страницу /second-password/, где ему необходимо будет ввести второй пароль. Если пароль будет введен правильно, то пользователь продолжит работу на сайте. Если же пароль будет неправильным, то пользователь будет разлогинен.

== Installation ==

Загрузите плагин Second Password Admin в свой блог, активируйте его, вместо «ваша_эл_почта» впишите ваш E-mail, а вместо «ваш_второй_пароль» — ваш второй пароль администратора.
Создайте пустую страницу WordPress /second-password/.
